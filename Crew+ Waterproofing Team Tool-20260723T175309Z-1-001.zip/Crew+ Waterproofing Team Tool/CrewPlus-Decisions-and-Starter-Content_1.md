# Crew+ — Decisions & Starter Content

*Companion to the Crew+ People & Performance Blueprint. This turns your answers to the open questions into concrete, editable starting content: a values library, a review structure, a KPI scaffold by role, a proposed bonus overhaul, your certification roster captured as an audit worksheet, and a rewards point economy. Everything here is a draft to react to — nothing is locked.*

---

## Team & org structure (12 people)

| Group | Roles | Count |
|---|---|---|
| Field | Crew Lead ×1, Technicians ×8 | 9 |
| Office | CFO ×1, Operations / Marketing / Accounting ×1, CEO ×1 | 3 |

This gives Crew+ a simple two-branch structure: a **field branch** (compliance, tools, truck tasks, safety KPIs, hands-on values) and an **office branch** (fewer certs, different KPIs, still in reviews, values, and the recognition wallet). Everyone rolls up to the CEO; the Crew Lead is the field manager, the Operations person is the natural admin/HR owner of the system, and the CFO owns the bonus/cost side.

---

## 1) Values & rituals — starter library (edit freely)

Five values sized for a below-grade waterproofing crew, each with a daily/weekly/monthly ritual and a concrete exercise. Keep four or five; more than that and none of them stick.

**Safety First, Always.** *Daily:* 30-second pre-job hazard call-out logged by the Crew Lead. *Weekly:* one "near-miss or catch" shared with the crew (no blame). *Monthly:* a 10-minute toolbox talk led by a different tech each month.

**Do It Right the First Time.** *Daily:* before leaving a stage, log one thing you'd be happy to inspect yourself. *Weekly:* review any callback/rework and what would've prevented it. *Monthly:* a "quality win of the month" recognized on the leaderboard.

**Own the Outcome.** *Daily:* close out your own tool/material logging same-day — no next-morning cleanup. *Weekly:* every open action item from your 1:1 gets moved forward or closed. *Monthly:* each person names one thing they'll take fuller ownership of next month.

**Leave It Better.** *Daily:* photo the site as you leave it. *Weekly:* one improvement to a truck, a process, or the warehouse. *Monthly:* team vote on the cleanest/most professional job site.

**Grow the Crew.** *Daily:* apprentices log one thing they learned; leads log one thing they taught. *Weekly:* a senior tech shadows or coaches on one skill. *Monthly:* one cert or skill goal progressed per person.

The Cadence & Nudge Engine delivers the daily one to phones each morning, the weekly one as a Friday prompt, and the monthly one as a team ritual — and each completion feeds points (see §5).

---

## 2) Review structure — recommendation

**Rating scale.** Use a simple **3-tier scale — Below / Meets / Exceeds** — for the crew. It's fast, hard to argue with, and works on a phone in the field; a 1–5 scale invites false precision and "everyone's a 4." Keep an optional **1–5 view for the office roles** if the CFO/CEO want finer tracking, but standardize the crew on three tiers.

**What each review scores.** The person's job-description responsibilities, your five values (are they living them), and their role KPIs — so a review is anchored to the role, not to memory.

**Cadence.**

- **New hires:** probation checkpoints at **30 / 60 / 90 days** — short, structured, mostly "are we a fit and are you set up to succeed."
- **Everyone, quarterly:** a **15-minute check-in** (Q1–Q4). Light: last quarter's notes, KPI status, one thing going well, one to work on, and the quarterly SWOT they've already filled in.
- **Everyone, annually:** the **formal review** — the full scorecard across responsibilities, values, and KPIs, feeding the December bonus decision.

The nudge engine counts down to each and reminds the manager the week before, so reviews stop slipping. Between reviews, managers drop lightweight feedback notes so the annual is a summary, not a scramble.

---

## 3) KPIs by role — scaffold (measurables left blank, as you asked)

A starting frame per role; we fill the actual numbers/targets together once you've seen it. Each role gets 3–5 KPIs so it stays focused.

**Crew Lead** — crew jobs on schedule; callback/rework rate; safety incidents; logging accuracy in Waterproofing+; apprentice development. *(targets: TBD)*

**Technician** — jobs completed to spec; rework on own work; safety compliance; tool/material logging discipline; certs kept current. *(TBD)*

**Senior Technician** — all Technician KPIs + quality on complex scopes (crack injection, traffic coatings) + mentoring contribution. *(TBD)*

**Operations / Marketing / Accounting** — job scheduling/throughput; review-lead generation & Google-review volume; AP/AR or invoicing timeliness. *(TBD)*

**Marketing** *(if split out)* — leads generated; Google reviews per month; cost per lead. *(TBD)*

**CFO** — gross margin by job; cost-report timeliness; cash/forecast accuracy; the profit figure that funds the bonus pool. *(TBD)*

**CEO** — company-level outcomes (revenue, margin, retention, safety record) — usually tracked, not "scored." *(TBD)*

---

## 4) Bonus — proposed overhaul (simpler, transparent, still profit-funded)

**What you have today:** profit-based, paid once a year in December, and clunky/opaque — nobody can see through the year how they're tracking, so it doesn't motivate day to day.

**The problem to fix:** the *pool* being profit-based is fine and worth keeping — it ties reward to company success. What's broken is that it's a black box paid out once, disconnected from the behavior it's meant to reward.

**Proposed model — "Profit pool, transparent scorecard, same December payout":**

1. **Fund the pool from profit** exactly as you do now: the bonus pool = a set **% of annual profit** the CFO confirms (keep whatever % you use).
2. **Split each person's share into two simple, visible factors** instead of a discretionary lump: `share = role weight × performance factor`, where **role weight** is a fixed number per role (set once — e.g., Crew Lead higher than Apprentice) and **performance factor** comes straight from their **quarterly review ratings averaged over the year** (Below/Meets/Exceeds → e.g., 0.7 / 1.0 / 1.3). Optionally a small **tenure bump**.
3. **Show progress all year.** Because the performance factor is just their review ratings, Crew+ can show each person an **"on track for bonus" indicator** every quarter (green/amber/red) without ever revealing dollars — the dollar figure stays admin-only, but the *trajectory* is visible, which is what makes it motivating.
4. **Still pay in December.** One payout, one moment, but now everyone understood how it was earned since January.

This keeps your profit linkage and your December timing, removes the discretion/opacity, and makes the number predictable from the reviews people already get. **Upload your current bonus program and I'll map it onto this structure precisely** — including your real profit %, role weights, and any floors/caps — and flag exactly what's making it clunky today.

---

## 5) Rewards — the shared point economy (Crew+ ⇄ Waterproofing+)

**One wallet, yes.** Points earned in either app land in the same balance and the same company leaderboard, so a perfect truck-task day and a 5★ Google review both count. Here's a proposed economy — anchor and all — to react to.

**Anchor:** roughly **1 point ≈ $0.05 of reward value**, so a strong month of good habits earns ~1,000–1,500 points and a $50 reward costs ~1,000. That pacing keeps rewards meaningful but reachable in weeks, not years.

### How points are earned

| Action | Points | Source app |
|---|---|---|
| Perfect daily truck-task day | +50 | Waterproofing+ *(exists)* |
| 5-day truck-task streak bonus | +25 | Waterproofing+ *(exists)* |
| Clean material/tool logging week (no corrections) | +40 | Waterproofing+ |
| All tools returned, none damaged (weekly) | +30 | Waterproofing+ |
| Daily value ritual | +30 | Crew+ |
| Weekly value exercise | +40 | Crew+ |
| Monthly value ritual | +60 | Crew+ |
| Quarterly SWOT on time | +80 | Crew+ |
| Company feedback form submitted | +40 | Crew+ |
| All your certs current (monthly, no lapses) | +50 | Crew+ |
| Review completed on time | +50 | Crew+ |
| KPI target hit (per period) | +100 | Crew+ |
| **5★ Google review naming you** | **+200** | Crew+ |
| Written customer compliment | +100 | Crew+ |
| Crew safety milestone (quarter incident-free) | +150 (each) | Crew+ |
| Peer recognition received | +20 | Crew+ |

*Guardrail:* cap the small habit points (rituals) at ~300/week so points reward behavior, not grinding; the big awards (reviews, reviews-from-customers, safety) are uncapped because you want more of those.

### What points buy (suggested catalog)

| Reward | Points | ~Value |
|---|---|---|
| Team lunch (you host it) | 600 | $30 |
| Company hoodie / gear | 800 | $40 |
| Leave 1 hr early on a Friday | 700 | — |
| $50 gas or gift card | 1,000 | $50 |
| First pick of next job / schedule | 1,500 | — |
| $100 gift card | 2,000 | $100 |
| Extra paid day off | 2,500 | ~$300 |
| Boots / premium tool allowance | 3,000 | $150 |
| Quarterly leaderboard champion | recognition + bonus points | — |

Tune the catalog to what your crew actually wants — the structure matters more than the exact items. A quarterly reset of the leaderboard (with the wallet carrying over) keeps newer people in the running.

---

## 6) Certification roster — audit worksheet (from your notes)

Captured exactly as you gave it, with status and — importantly — **what's missing**. Half the value of the compliance module is surfacing the gaps below; today = **Jul 16, 2026**.

| Person | Certification | Status | Expiry on file? |
|---|---|---|---|
| **Jesse** | WHMIS | Active | ❓ date needed |
| | Hearing | Active | ❓ date needed |
| | Level 1 First Aid | 🔴 **Expired** | needs renewal now |
| | Fit Test | 🟠 last tested **Sep 9 2025** — annual, likely **overdue** | confirm renewal |
| | Lift | Active | ❓ date needed |
| **Shane** | Lift Operation | Active | ❓ date needed — *only 1 cert on file* |
| **Jon** | Lift Operation | Active | ❓ date needed |
| | Level 1 First Aid | 🟢 Current | expires **Feb 2028** |
| | Fit Test | Active | ❓ date needed |
| | Confined Spaces | Active | ❓ date needed |
| **Josh** | Fall Arrest | Active | ❓ date needed |
| | Lift | Active | ❓ date needed |
| | Confined Spaces | Active | ❓ date needed |
| **Logan** | — | 🔴 **No certs on file** | full audit needed |
| **Thorpe** | Lift Operation | Active | ❓ date needed |
| | Level 1 First Aid | 🟢 Current | expires **Feb 2028** |
| | Fit Test | Active | ❓ date needed |
| | Confined Spaces | Active | ❓ date needed |
| **Rogers** | Level 1 First Aid | 🟢 Current | expires **Feb 2028** |
| | Fit Test | Active | ❓ date needed |

**Immediate flags the system would raise today:**

- 🔴 **Jesse — Level 1 First Aid expired.** Renew now.
- 🟠 **Jesse — Fit Test** dated Sep 9 2025; fit tests are annual, so this is likely overdue — confirm and rebook.
- 🔴 **Logan — no certifications on record.** Either a data gap or a real compliance hole; audit before next high-risk work.
- 🟡 **Shane — only Lift on file.** Likely missing WHMIS/First Aid/Fit Test records — confirm.
- ⚪ **Most certs have no expiry date recorded.** The single highest-value data-entry task is adding issue/expiry dates so the 60/30/7-day alerts can actually fire. Fit tests and First Aid are the ones that lapse most, so start there.

*(I've reflected this real roster and these flags directly in the updated prototype's Compliance module.)*

---

## Still open / next inputs

- Your real **KPI targets** per role (the blank measurables in §3).
- Your **current bonus program** document — upload it and I'll map it onto the §4 structure and simplify it concretely.
- **Cert expiry dates** — the missing dates in §6, especially Fit Test and First Aid.
- Whether the **five values in §1** are yours or want swapping — this is the most personal part; make them sound like your company.
